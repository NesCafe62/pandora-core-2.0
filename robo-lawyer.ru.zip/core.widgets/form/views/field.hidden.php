<?php

/** @var string $name */
/** @var mixed $value */
?>
<input type="hidden" name="<?= $name ?>" value="<?= $value ?>">