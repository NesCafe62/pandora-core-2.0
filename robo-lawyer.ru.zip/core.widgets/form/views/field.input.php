<?php

/** @var string $name */
/** @var mixed $value */
?>
<input type="text" name="<?= $name ?>" value="<?= $value ?>">