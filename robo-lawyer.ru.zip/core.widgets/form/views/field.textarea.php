<?php

/** @var string $name */
/** @var mixed $value */
?>
<textarea name="<?= $name ?>"><?= $value ?></textarea>