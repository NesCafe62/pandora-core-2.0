<?php

/** @var string $name */
?>
<input type="password" name="<?= $name ?>" value="">