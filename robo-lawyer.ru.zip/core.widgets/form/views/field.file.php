<?php

/** @var string $name */
/** @var mixed $value */
?>
<input type="file" name="<?= $name ?>">
<div class="file-value"><?= $value['name'] ?? '' ?></div>