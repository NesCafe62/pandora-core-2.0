(function() {

	/* function init (converter) {
		function api (key, value, attributes) {
			var result;

			// Write

			if (arguments.length > 1) {
				attributes = $.extend({
					path: '/'
				}, api.defaults, attributes);

				if (typeof attributes.expires === 'number') {
					var expires = new Date();
					expires.setMilliseconds(expires.getMilliseconds() + attributes.expires * 864e+5);
					attributes.expires = expires;
				}

				try {
					result = JSON.stringify(value);
					if (/^[\{\[]/.test(result)) {
						value = result;
					}
				} catch (e) {}

				if (!converter.write) {
					value = encodeURIComponent(String(value))
						.replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent);
				} else {
					value = converter.write(value, key);
				}

				key = encodeURIComponent(String(key));
				key = key.replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent);
				key = key.replace(/[\(\)]/g, escape);

				return (document.cookie = [
					key, '=', value,
					attributes.expires && '; expires=' + attributes.expires.toUTCString(), // use expires attribute, max-age is not supported by IE
					attributes.path    && '; path=' + attributes.path,
					attributes.domain  && '; domain=' + attributes.domain,
					attributes.secure ? '; secure' : ''
				].join(''));
			}

			// Read

			if (!key) {
				result = {};
			}

			// To prevent the for loop in the first place assign an empty array
			// in case there are no cookies at all. Also prevents odd result when
			// calling "get()"
			var cookies = document.cookie ? document.cookie.split('; ') : [];
			var rdecode = /(%[0-9A-Z]{2})+/g;
			var i = 0;

			for (; i < cookies.length; i++) {
				var parts = cookies[i].split('=');
				var name = parts[0].replace(rdecode, decodeURIComponent);
				var cookie = parts.slice(1).join('=');

				if (cookie.charAt(0) === '"') {
					cookie = cookie.slice(1, -1);
				}

				try {
					cookie = converter.read ?
						converter.read(cookie, name) : converter(cookie, name) ||
						cookie.replace(rdecode, decodeURIComponent);

					if (this.json) {
						try {
							cookie = JSON.parse(cookie);
						} catch (e) {}
					}

					if (key === name) {
						result = cookie;
						break;
					}

					if (!key) {
						result[name] = cookie;
					}
				} catch (e) {}
			}

			return result;
		}

		api.get = api.set = api;
		api.getJSON = function () {
			return api.apply({
				json: true
			}, [].slice.call(arguments));
		};
		api.defaults = {};

		api.remove = function (key, attributes) {
			api(key, '', $.extend(attributes, {
				expires: -1
			}));
		};

		api.withConverter = init;

		return api;
	}

	$.cookie = init( function() {} ); */

	$.cookie = {

		get: function (key, defaultValue, attributes) {
			var result;

			if (!key) {
				console.log('$.cookie.get error: key value is empty');
				return defaultValue;
			}

			// To prevent the for loop in the first place assign an empty array
			// in case there are no cookies at all. Also prevents odd result when
			// calling "get()"
			var cookies = document.cookie ? document.cookie.split('; ') : [];
			var regexDecode = /(%[0-9A-Z]{2})+/g;

			for (var i = 0; i < cookies.length; i++) {
				var parts = cookies[i].split('=');
				var name = parts[0].replace(regexDecode, decodeURIComponent);
				var cookie = parts.slice(1).join('=');

				if (cookie.charAt(0) === '"') {
					cookie = cookie.slice(1, -1);
				}

				try {
					/* cookie = converter.read ?
						converter.read(cookie, name) : converter(cookie, name) ||
						cookie.replace(regexDecode, decodeURIComponent); */

					cookie = cookie.replace(regexDecode, decodeURIComponent);

					if (this.json) {
						try {
							cookie = JSON.parse(cookie);
						} catch (e) {}
					}

					if (key === name) {
						result = cookie;
						break;
					}

					if (!key) {
						result[name] = cookie;
					}
				} catch (e) {
					console.log('$.cookie.get error: JSON.parse key="'+key+'"');
				}
			}

			return (result !== undefined) ? result : defaultValue;
		},

		set: function (key, value, attributes) {
			var result;

			attributes = $.default(attributes, {path: '/'});

			if (typeof attributes.expires === 'number') {
				var expires = new Date();
				expires.setMilliseconds(expires.getMilliseconds() + attributes.expires * 864e+5);
				attributes.expires = expires;
			}

			try {
				result = JSON.stringify(value);
				if (/^[\{\[]/.test(result)) {
					value = result;
				}
			} catch (e) {
				console.log('$.cookie.set error: JSON.stringify key="'+key+'"');
			}

			/* if (!converter.write) {
				value = encodeURIComponent(String(value))
					.replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent);
			} else {
				value = converter.write(value, key);
			} */

			value = encodeURIComponent(String(value)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent);

			key = encodeURIComponent(String(key));
			key = key.replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent);
			key = key.replace(/[\(\)]/g, escape);

			document.cookie = [
				key, '=', value,
				attributes.expires && '; expires=' + attributes.expires.toUTCString(), // use expires attribute, max-age is not supported by IE
				attributes.path    && '; path=' + attributes.path,
				attributes.domain  && '; domain=' + attributes.domain,
				attributes.secure ? '; secure' : ''
			].join('');
		},

		getJSON: function() {
			return this.get.apply(
				{json: true},
				[].slice.call(arguments)
			);
		},

		clear: function(key, attributes) {
			this.set(
				key, '',
				$.default({expires: -1}, attributes)
			);
		}

	};

})();