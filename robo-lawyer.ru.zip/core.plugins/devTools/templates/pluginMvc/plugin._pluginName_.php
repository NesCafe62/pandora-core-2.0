<?php
namespace _pluginNamespace_;

use core\libs\plugin;

class _pluginName_ extends plugin {

}