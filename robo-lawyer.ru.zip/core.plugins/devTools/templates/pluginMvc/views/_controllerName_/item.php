<h2>_modelName_</h2>
<div class="_modelName_-info">
	<button onclick="window.location.href='/_modelName_s'" class="button button-back">Back</button>
	<?php /* <div class="title"><?= $_modelName_->title ?></div> */ ?>
	<?php /* <div class="count">count: <?= $_modelName_->count ?></div> */ ?>
</div>